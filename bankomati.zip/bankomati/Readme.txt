gadaitanet accounts.txt desktopze
