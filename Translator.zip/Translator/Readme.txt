gadaitanet translations.txt desktopze
